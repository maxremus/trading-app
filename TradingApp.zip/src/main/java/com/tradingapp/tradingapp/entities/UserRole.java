package com.tradingapp.tradingapp.entities;

public enum UserRole {

    USER,
    ADMIN
}
